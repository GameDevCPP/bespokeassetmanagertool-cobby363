#include <SFML/Graphics.hpp>
#include <iostream>
#include <nlohmann/json.hpp> //#include "json.hpp"
#include <fstream>
#include "TileMap.h"
#include <TGUI/TGUI.hpp>


int TileSelected  = 0;

void ChooseTile(int x){
    TileSelected = x;
}

int main()
{

    int mapStart = 89;
	//new json object to store map data
	nlohmann::json j;
	std::ofstream outJson("MapLevel1.json");
	std::ifstream inJson("MapLevel1.json");
	// create the window
	
	sf::RenderWindow window(sf::VideoMode(512, 350), "Tilemap");
	window.setVerticalSyncEnabled(true); //I want this to limit the framerates and not cook my cpu!!

	tgui::GuiSFML gui{ window };

	tgui::Button::Ptr button = tgui::Button::create();
    tgui::Button::Ptr button2 = tgui::Button::create();
    tgui::Button::Ptr button3 = tgui::Button::create();
    tgui::Button::Ptr button4 = tgui::Button::create();
    tgui::Picture::Ptr tileImage = tgui::Picture::create("tileset.png");
	auto editBox = tgui::EditBox::create();

	gui.add(button);
	gui.add(button2);
	gui.add(button3);
	gui.add(button4);

    gui.add(tileImage);

    //buttons
    button ->setPosition("25%", 64);
    button ->setSize(64, 25);
    button ->setText("Set Tile");
    button2 ->setPosition(192, 64);
    button2 ->setSize(64, 25);
    button2 ->setText("Set Tile");
    button3 ->setPosition(256, 64);
    button3 ->setSize(64, 25);
    button3 ->setText("Set Tile");
    button4 ->setPosition(320, 64);
    button4 ->setSize(64, 25);
    button4 ->setText("Set Tile");
    button->onPress([&]{ ChooseTile(0); });
    button2->onPress([&]{ ChooseTile(1); });
    button3->onPress([&]{ ChooseTile(2); });
    button4->onPress([&]{ ChooseTile(3); });
    //Image
    tileImage ->setSize(512, 64);
    tileImage ->setPosition("25%", "0");
	



	// define the level with an array of tile indices


//Change to using JSON
//save the data to map.json
//load back into new json object called j2;
//use that to populate level/map info.
	j["level"] = {
		0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
		0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0,
		1, 1, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3,
		0, 1, 0, 0, 2, 0, 3, 3, 3, 0, 1, 1, 1, 0, 0, 0,
		0, 1, 1, 0, 3, 3, 3, 0, 0, 0, 1, 1, 1, 2, 0, 0,
		0, 0, 1, 0, 3, 0, 2, 2, 0, 0, 1, 1, 1, 1, 2, 0,
		2, 0, 1, 0, 3, 0, 2, 2, 2, 0, 1, 1, 1, 1, 1, 1,
		0, 0, 1, 0, 3, 2, 2, 2, 0, 0, 0, 0, 1, 1, 1, 1,
	};
	j["tileset"] = "tileset.png";
	j["TileSize"] = { 32,32 };
	j["MapDims"] = { 16,8 };

	//save our json file
	outJson << j << std::endl;

	//I'm going to load in my json data file. Let's pretend a highly skilled level designer spent hours on this level ;)
	nlohmann::json jsonMap;

	inJson >> jsonMap;

	//did it load correctly or is it rubbish - let's take a look. This is a simple form of debugging.
	std::cout << jsonMap["level"] << std::endl;

	// create the tilemap from the level definition
	TileMap map;

	//copy map data to suitable structure
	std::vector<int> levelVector = jsonMap["level"];
	const std::string tileset(jsonMap["tileset"]);
	sf::Vector2u mapSize(jsonMap["MapDims"][0], jsonMap["MapDims"][1]);
	sf::Vector2u tileSize(jsonMap["TileSize"][0], jsonMap["TileSize"][1]);

	MapData mapData{ tileset, tileSize, &levelVector[0], mapSize.x, mapSize.y };
	if (!map.load(mapData)) {
		return -1; //if problem we bail out of here!
	}//neat trick to pass a vector as a const array! See https://stackoverflow.com/questions/2923272/how-to-convert-vector-to-array


	// run the main loop
	//while (window.isOpen())
	//{
	//	// handle events
	//	sf::Event event;
	//	while (window.pollEvent(event))
	//	{
	//		if (event.type == sf::Event::Closed)
	//			window.close();
	//	}

	//	// draw the map
	//	window.clear();
	//	window.draw(map);
	//	window.display();
	//}

    //Map Edits
    int y = 95;
    map.setPosition(0, y);


	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			gui.handleEvent(event);

			if (event.type == sf::Event::Closed)
				window.close();
		}

		window.clear();
		window.draw(map);
		gui.draw();

		window.display();

        if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
            auto mousePos = sf::Mouse::getPosition(window);
            mousePos.y -= y;
            std::cout << "Mouse Position : (" << mousePos.x << "," << mousePos.y << ")" << std::endl;
            if(mousePos.y >= 0) {
                sf::Vector2u logicalCoords(mousePos.x / tileSize.x, mousePos.y / tileSize.y);
                std::cout << "Logical Coordinates : (" << logicalCoords.x << "," << logicalCoords.y << ")" << std::endl;

                auto TileNumber=(logicalCoords.y)*mapSize.x + (logicalCoords.x);

                mapData.tiles_[TileNumber] = TileSelected;

                if (!map.load(mapData)) {
                    return -1;
                }


            }
        }


	}

	return 0;
}
