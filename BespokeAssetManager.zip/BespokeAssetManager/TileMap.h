#include <SFML/Graphics.hpp>
#include <iostream>
#include <nlohmann/json.hpp> //#include "json.hpp"
#include <fstream>


//suitable data structure
struct MapData
{
	MapData(const std::string& tileset, sf::Vector2u tileSize, int* tiles, unsigned int width, unsigned int height) :name_(tileset), tileSize_(tileSize), width_(width), height_(height), tiles_(tiles)
	{

	}
	const std::string name_;
	sf::Vector2u tileSize_;
	int* tiles_;
	unsigned int width_;
	unsigned int height_;

};
class TileMap : public sf::Drawable, public sf::Transformable
{
public:
	/*  bool load(const std::string& tileset, sf::Vector2f tileSize, std::vector tiles, unsigned int width, unsigned int height)
	  {}
  */
	bool load(MapData mapData);

	bool load(const std::string& tileset, sf::Vector2u tileSize, const int* tiles, unsigned int width, unsigned int height);
	

private:

	virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const;

	sf::VertexArray m_vertices;
	sf::Texture m_tileset;
};


